# main.py
import base64
import json
import os
import time

from googleapiclient import discovery

# Environment variable set by Cloud Functions
PROJECT_ID = os.getenv("GCP_PROJECT")
PROJECT_NAME = f"projects/{PROJECT_ID}"

def stop_billing(data, context):
    # Decode the Pub/Sub message data
    try:
        pubsub_data = base64.b64decode(data.get("data", b""))
        pubsub_str = pubsub_data.decode("utf-8")
        print(f"Pubsub data is : {pubsub_str}")
    except Exception as e:
        print(f"Failed to decode Pub/Sub message data: {e}")
        return

    # Parse JSON payload for cost and budget
    try:
        pubsub_json = json.loads(pubsub_str)
        cost_amount = pubsub_json["costAmount"]
        budget_amount = pubsub_json["budgetAmount"]
    except (json.JSONDecodeError, KeyError) as e:
        print(f"Received message is not valid JSON with costAmount and budgetAmount: {e}")
        return

    print(f"Project ID is : {PROJECT_ID}")
    print(f"PROJECT_NAME is : {PROJECT_NAME}")
    print(f"cost Amount is : {cost_amount}")
    print(f"budgetAmount is : {budget_amount}")

    # Warn when spend reaches or exceeds 100% of budget
    try:
        if cost_amount >= budget_amount:
            warning_msg = (
                "WARNING: You have reached 100% of your budget. Your project will be detached from the billing account imminently if spending continues."
            )
            print(warning_msg)
    except Exception as e:
        print(f"Error evaluating warning threshold: {e}")

    # No action needed if under or equal to budget
    if cost_amount <= budget_amount:
        print(f"No action necessary. (Current cost: {cost_amount})")
        return

    if not PROJECT_ID:
        print("No project specified with environment variable")
        return

    # Delay before detaching billing to allow any final operations
    try:
        print("Waiting 2 minutes before detaching billing...")
        time.sleep(120)
    except Exception as e:
        print(f"Sleep interrupted: {e}")

    billing = discovery.build(
        "cloudbilling",
        "v1",
        cache_discovery=False,
    )
    projects = billing.projects()

    billing_enabled = __is_billing_enabled(PROJECT_NAME, projects)
    if billing_enabled:
        __disable_billing_for_project(PROJECT_NAME, projects)
    else:
        print("Billing already disabled")

def __is_billing_enabled(project_name, projects):
    """
    Check if billing is enabled for the project
    """
    print("Inside __is_billing_enabled function")
    try:
        res = projects.getBillingInfo(name=project_name).execute()
        return res.get("billingEnabled", False)
    except Exception:
        print("Unable to determine if billing is enabled; assuming enabled")
        return True

def __disable_billing_for_project(project_name, projects):
    """
    Disable billing by removing the billing account
    """
    print("Inside __disable_billing_for_project function")
    body = {"billingAccountName": ""}
    try:
        res = projects.updateBillingInfo(name=project_name, body=body).execute()
        print(f"Billing disabled: {json.dumps(res)}")
    except Exception:
        print("Failed to disable billing; check permissions")
